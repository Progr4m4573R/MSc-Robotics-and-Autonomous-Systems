# tallon.py
#
# The code that defines the behaviour of Tallon. This is the place
# (the only place) where you should write code, using access methods
# from world.py, and using makeMove() to generate the next move.
#
# Written by: Simon Parsons
# Last Modified: 12/01/22
from email import policy
import numpy as np
import world
import random
import utils
from utils import Directions
import mdptoolbox
import config
class Tallon():

    def __init__(self, arena):

        # Make a copy of the world an attribute, so that Tallon can
        # query the state of the world
        self.gameWorld = arena

        # What moves are possible.
        self.moves = [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]#CHECK UTILS FOR DIRECTION VALUES
        self.movevalues = [0,1,2,3]
    def makeMove(self):
        # This is the function you need to define

        # For now we have a placeholder, which always moves Tallon
        # directly towards any existing bonuses. It ignores Meanies
        # and pits.
        # 
        # Get the location of the Bonuses.
        Policyvalue=0
        print("policy value")
        for m in self.movevalues:
            if  m == Policyvalue: #2 for south
                print("chose to move",self.moves[m])
            

        allBonuses = self.gameWorld.getBonusLocation()
        allpits = self.gameWorld.getPitsLocation()
        allmeanies = self.gameWorld.getMeanieLocation()
        myPosition = self.gameWorld.getTallonLocation()
        search = utils.pickRandomPose(myPosition.x,myPosition.y)

        #Policy iteration

        self.fill_in_probs()
        c = 10
        r = 10
        arr = [[0] * c for i in range(r)] # loop will run for the length of the outer list
        try:
            for i in range(r):
            # loop will run for the length of the inner lists
                for j in range(c):
                    if i == allBonuses[0] and j == allBonuses[0].y:
                        arr[i][j] = 1 #positive reward for goals
                    if i == allpits[0].x and j == allpits[0].y:
                        arr[i][j] = -1 #Negative reward for pits
                    if i == allmeanies[0].x and j == allmeanies[0].y:
                        arr[i][j] = -1 #Negative reward for meanies
                    else:
                        arr[i][j] == 0
                # for r in arr:
                #     print( ' '.join([str(x) for x in r] ) )
        except Exception as e:
            print(e)
        #Shows updating policy as time goes on. The values in this need to be parsed to a function to create updating Optimum policy
        #print(arr)
        #self.bellmanEq(arr)
        # if there are still bonuses, move towards the next one.
        #self.rewards(allBonuses)
        if len(allBonuses) > 0:
            print("Moving to bonuses...")
            nextBonus = allBonuses[0]
            
            # If not at the same x coordinate, reduce the difference
            if nextBonus.x > myPosition.x:
                return Directions.EAST
            if nextBonus.x < myPosition.x:
                return Directions.WEST
            # If not at the same y coordinate, reduce the difference
            if nextBonus.y > myPosition.y:
                return Directions.NORTH
            if nextBonus.y < myPosition.y:
                return Directions.SOUTH
        print("Searching for bonuses")
        if search.x > myPosition.x:
            return Directions.EAST
        if search.x < myPosition.x:
            return Directions.WEST
        # If not at the same y coordinate, reduce the difference
        if search.y > myPosition.y:
            return Directions.NORTH
        if search.y < myPosition.y:
            return Directions.SOUTH
        # if there are no more bonuses, Tallon doesn't move
    

    # def rewards(self,allBonuses):
    #     c = 4
    #     r = 100
    #     rewardsarray = [[0] * c for i in range(r)] 
        
    #     for i in range(r):
    #         for j in range(c):
    #             #if the row has a reward then that state is favourable
    #             if i == allBonuses[0].x :
    #                 rewardsarray[i][j] = 1 #positive reward for goals
    #             else:
    #                 rewardsarray[i][j] =-0.04
    #     print(rewardsarray) 

        

    def fill_in_probs(self):
        grid_size = (10, 10)
        black_cells = self.gameWorld.getPitsLocation()
        white_cell_reward = -0.04
        allBonuses = self.gameWorld.getBonusLocation()
        allmeanies= self.gameWorld.getMeanieLocation()
        bonuses_reward=1.0
        meanies_reward=-1.0
        action_North_South_East_West=(.025, .025, config.directionProbability, 0.)       
                  
        num_states = grid_size[0] * grid_size[1]
        num_actions = 4
        P = np.zeros((num_actions, num_states, num_states))
        R = np.zeros((num_states, num_actions))
        
        # converts the multidimentional grid to a 1 dimentional grid
        to_1d = lambda x: np.ravel_multi_index(x, grid_size)

        def hit_wall(cell):
            if cell in black_cells:
                return True
            try: # ...good enough...
                to_1d(cell)
            except ValueError as e:
                return True
            return False
    #########################################################################################
        # make probs for each action
        
        North = [action_North_South_East_West[i] for i in (0, 1, 2, 3)]#up
        South = [action_North_South_East_West[i] for i in (1, 0, 3, 2)]#down
        West = [action_North_South_East_West[i] for i in (2, 3, 1, 0)]#left
        East = [action_North_South_East_West[i] for i in (3, 2, 0, 1)]#right
        actions = [North, South, East, West]
        for i, a in enumerate(actions):
            actions[i] = {'North':a[2], 'South':a[3], 'West':a[0], 'East':a[1]}
            
        # work in terms of the 2d grid representation

        def update_P_and_R(cell, new_cell, a_index, a_prob):
            print("update p and r called")
            if cell == allBonuses:
                P[a_index, to_1d(cell), to_1d(cell)] = 1.0
                R[to_1d(cell), a_index] = bonuses_reward
                
            elif cell == allmeanies:
                P[a_index, to_1d(cell), to_1d(cell)] = 1.0
                R[to_1d(cell), a_index] = meanies_reward

            elif hit_wall(new_cell):  # add prob to current cell
                P[a_index, to_1d(cell), to_1d(cell)] += a_prob
                R[to_1d(cell), a_index] = white_cell_reward
                print("hit wall code")
            else:
                P[a_index, to_1d(cell), to_1d(new_cell)] = a_prob
                R[to_1d(cell), a_index] = white_cell_reward
            
            for a_index, action in enumerate(actions):
                for cell in np.ndindex(grid_size):
                    # up
                    new_cell = (cell[0]-1, cell[1])#subtracting from row makes us go up to previous row
                    update_P_and_R(cell, new_cell, a_index, action['North'])

                    # down
                    new_cell = (cell[0]+1, cell[1])#adding to row makes us go down a row
                    update_P_and_R(cell, new_cell, a_index, action['South'])

                    # left
                    new_cell = (cell[0], cell[1]-1)
                    update_P_and_R(cell, new_cell, a_index, action['West'])
                    # right
                    new_cell = (cell[0], cell[1]+1)
                    update_P_and_R(cell, new_cell, a_index, action['East'])
            print(P)
            print(R)
            return P, R

          

