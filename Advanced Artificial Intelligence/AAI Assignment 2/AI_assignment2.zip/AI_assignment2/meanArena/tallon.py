# tallon.py
#
# The code that defines the behaviour of Tallon. This is the place
# (the only place) where you should write code, using access methods
# from world.py, and using makeMove() to generate the next move.
#
# Written by: Simon Parsons
# Last Modified: 12/01/22
import numpy as np
import world
import random
import utils
from utils import Directions
import mdptoolbox
class Tallon():

    def __init__(self, arena):

        # Make a copy of the world an attribute, so that Tallon can
        # query the state of the world
        self.gameWorld = arena

        # What moves are possible.
        self.moves = [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]
        
    def makeMove(self):
        # This is the function you need to define

        # For now we have a placeholder, which always moves Tallon
        # directly towards any existing bonuses. It ignores Meanies
        # and pits.
        # 
        # Get the location of the Bonuses.
        allBonuses = self.gameWorld.getBonusLocation()
        allpits = self.gameWorld.getPitsLocation()
        allmeanies = self.gameWorld.getMeanieLocation()
        myPosition = self.gameWorld.getTallonLocation()
        search = utils.pickRandomPose(myPosition.x,myPosition.y)

        #Policy iteration
        c = 10
        r = 10
        arr = [[0] * c for i in range(r)] # loop will run for the length of the outer list
        try:
            for i in range(r):
            # loop will run for the length of the inner lists
                for j in range(c):
                    if i == allBonuses[0] and j == allBonuses[0].y:
                        arr[i][j] = 1 #positive reward for goals
                    if i == allpits[0].x and j == allpits[0].y:
                        arr[i][j] = -1 #Negative reward for pits
                    if i == allmeanies[0].x and j == allmeanies[0].y:
                        arr[i][j] = -1 #Negative reward for meanies
                    else:
                        arr[i][j] == 0
                # for r in arr:
                #     print( ' '.join([str(x) for x in r] ) )
        except Exception as e:
            print(e)
        #Shows updating policy as time goes on. The values in this need to be parsed to a function to create updating Optimum policy
        #print(arr)
        self.bellmanEq(arr)
        # if there are still bonuses, move towards the next one.
        if len(allBonuses) > 0:
            print("Moving to bonuses...")
            nextBonus = allBonuses[0]
            
            # If not at the same x coordinate, reduce the difference
            if nextBonus.x > myPosition.x:
                return Directions.EAST
            if nextBonus.x < myPosition.x:
                return Directions.WEST
            # If not at the same y coordinate, reduce the difference
            if nextBonus.y > myPosition.y:
                return Directions.NORTH
            if nextBonus.y < myPosition.y:
                return Directions.SOUTH
        print("Searching for bonuses")
        if search.x > myPosition.x:
            return Directions.EAST
        if search.x < myPosition.x:
            return Directions.WEST
        # If not at the same y coordinate, reduce the difference
        if search.y > myPosition.y:
            return Directions.NORTH
        if search.y < myPosition.y:
            return Directions.SOUTH
        # if there are no more bonuses, Tallon doesn't move
    
    #Function for bellman policy which needs to be converted into update rule
    def bellmanEq(self,arr):
        for i in range(10):
            for j in range(10):
                if arr[i][j]>0:
                    #left                                                                     #down                         #up
                    arr[-i][j] = (0.95*(arr[i][j] +arr[i][j]*0.9) + 0.025*(arr[i][j] + arr[i][-j]*0.9) + 0.025*(arr[i][j]+arr[i][+j]*0.9)) 
        print(arr)
