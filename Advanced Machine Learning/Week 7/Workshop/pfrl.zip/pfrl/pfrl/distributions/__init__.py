from pfrl.distributions.delta import Delta  # NOQA
