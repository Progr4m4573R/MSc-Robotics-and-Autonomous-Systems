# Add lecun_normal weight initialization for networks in pytorch
from pfrl.initializers.chainer_default import init_chainer_default  # NOQA
from pfrl.initializers.lecun_normal import init_lecun_normal  # NOQA
