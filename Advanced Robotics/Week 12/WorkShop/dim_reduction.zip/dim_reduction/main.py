from tkinter import END
import numpy as np
from sklearn.manifold import LocallyLinearEmbedding
from sklearn.manifold import TSNE

import pandas as pd


#https://www.analyticsvidhya.com/blog/2021/08/python-tutorial-working-with-csv-file-for-data-science/
def import_dataset(dataset_name):
    # This functions imports the dataset and returns the regression inputs and targets.
    # For the Baxter dataset the inputs are the first 21 rows (joints' positions, velocities and acceleratations)
    # and the outputs the last seven (torques applied on each joint)
    # Input:
    # dataset_name: string of the filename
    dataset = pd.read(dataset_name) 
    regression_inputs = []
    regression_targets = []

    rows = list(dataset)
    regression_inputs = rows[0:21]
    regression_targets = rows[-7:-1]

    # Return:
    #       regression_inputs: A N times D Numpy array (N: number of samples, D: dimensions) 
    #       regression_outputs: Numpy array
    return [regression_inputs, regression_targets]

def evaluate_lle(regression_inputs, low_dimensionality, neighbours):
    # Apply LLE on the inputs and return the reconstruction error. See: https://scikit-learn.org/stable/modules/generated/sklearn.manifold.LocallyLinearEmbedding.html
    # Input:
    # regression_inputs: numpy array
    # low_dimensionality: scalar, the desired dimensionality of the embedding, best is 10,40,35
    # neighbours: scalar, Neighbours to consider for the reconstruction best is 10-12
    embedding = LocallyLinearEmbedding() 
    regression_inputs_transformed = embedding.fit_transform(regression_inputs[:100])

    # Return:
    #       reconstruction error: Error of the optimization
    reconstruction_error = regression_inputs_transformed - low_dimensionality
    return reconstruction_error

def tsne(regression_inputs, low_dimensionality, perplexity):
    # Apply tSNE on the inputs and return the reconstruction error. See: https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html#sklearn.manifold.TSNE
    # Input:
    #       regression_inputs: numpy array
    #       low_dimensionality: scalar, the desired dimensionality of the embedding
    #       perplexity: scalar, Controls the amount of neighbours to be considered.  Recomended values between 5 and 50.
    n_components = len(regression_inputs.size)
    x_embedding = TSNE(n_components, learning_rate='auto',init='random').fit_transform(regression_inputs)
    # Return:
    #       reconstruction error: Error of the optimization
    reconstruction_error = x_embedding - low_dimensionality
    return reconstruction_error


if __name__ == '__main__':
    [regression_inputs, regression_targets] = import_dataset('BaxterData.csv')
    lle_reconstruction_error = evaluate_lle(regression_inputs,35,12)
    tsne_reconstruction_error = tsne(regression_inputs,35,5)
print("LLE Reconstruction error is: ", lle_reconstruction_error,"\n","TSNE Reconstruction error is: ", tsne_reconstruction_error)
