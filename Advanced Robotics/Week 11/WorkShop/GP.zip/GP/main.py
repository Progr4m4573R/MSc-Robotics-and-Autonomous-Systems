import numpy as np
from sklearn.gaussian_process import gpr
from sklearn.gaussian_process import kernels




def import_dataset(dataset_name):
    # This functions imports the dataset and returns the regression inputs and targets.
    # For the Baxter dataset the inputs are the first 21 rows (joints' positions, velocities and acceleratations)
    # and the outputs the last seven (torques applied on each joint)
    # Input:
    #       dataset_name: string of the filename
    # Return:
    #       regression_inputs: A N times D Numpy array (N: number of samples, D: dimensions)
    #       regression_outputs: Numpy array
    return [regression_inputs, regression_targets]

def get_cross_validation_sets(regression_inputs, regression_targets):
    # Use the k-fold cross validation to generate training and testing sets ( see sklearn.model_selection.KFold)
    # This should return k sets of regression inputs and outputs
    # Input:
    #       regression_inputs: numpy array
    #       regression_outputs: Numpy array
    # Return:
    #       k_fold_regression_input: A k times N times d Numpy array
    #       k_fold_regression_outputs:  A k times N times d Numpy array
    return [k_fold_regression_input, k_fold_regression_outputs]

def train_gp_model(k_fold_regression_inputs,k_fold_regression_outputs,kernel):
    # Train k GP models using the specified kernel and the inputs-outputs (see sklearn.gaussian_process.GaussianProcessRegressor)
    # This should return k trained models, one for each fold
    # Input:
    #       kernel: sklearn.gaussian_process.kernel object.
    #       regression_inputs: numpy array
    #       regression_outputs: Numpy array
    # Return:
    #       k_gp_models: An array of k trained GP models
    return k_gp_models

def predict_gp(k_fold_regression_inputs,k_fold_regression_outputs,k_gp_models):
    # Use the trained GP model to make predictions on the data and measure the mean square error between the predicted  and true values
    return mse

if __name__ == '__main__':
    [regression_inputs, regression_targets] = import_dataset(dataset_name)
    [k_fold_regression_input, k_fold_regression_outputs] = get_cross_validation_sets(regression_inputs, regression_targets)
    k_gp_models = train_gp_model(k_fold_regression_input, k_fold_regression_outputs, kernel)
    mse = predict_gp(k_fold_regression_input,k_fold_regression_outputs,k_gp_models)
